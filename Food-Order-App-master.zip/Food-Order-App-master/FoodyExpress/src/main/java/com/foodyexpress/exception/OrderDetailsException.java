package com.foodyexpress.exception;

public class OrderDetailsException extends Exception {

	public OrderDetailsException() {
		// TODO Auto-generated constructor stub
	}

	public OrderDetailsException(String message) {
		// TODO Auto-generated constructor stub
		super(message);
	}

}
