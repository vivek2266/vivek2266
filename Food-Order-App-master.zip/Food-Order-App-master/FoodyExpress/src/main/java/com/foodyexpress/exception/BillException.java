package com.foodyexpress.exception;

public class BillException extends Exception {

	public BillException() {
		// TODO Auto-generated constructor stub
	}

	public BillException(String message) {
		// TODO Auto-generated constructor stub
		super(message);
	}

}
