package com.foodyexpress.exception;

public class CategoryException extends Exception {

	public CategoryException() {
		// TODO Auto-generated constructor stub
	}

	public CategoryException(String message) {
		// TODO Auto-generated constructor stub
		super(message);
	}

}
