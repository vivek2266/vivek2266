package com.foodyexpress.exception;

public class OrderHistoryException extends Exception {

	public OrderHistoryException() {
		// TODO Auto-generated constructor stub
	}

	public OrderHistoryException(String message) {
		// TODO Auto-generated constructor stub
		super(message);
	}

}
