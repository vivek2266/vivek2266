package com.foodyexpress.exception;

public class AddressException extends Exception {

	public AddressException() {
		// TODO Auto-generated constructor stub
	}

	public AddressException(String message) {
		// TODO Auto-generated constructor stub
		super(message);
	}

}
