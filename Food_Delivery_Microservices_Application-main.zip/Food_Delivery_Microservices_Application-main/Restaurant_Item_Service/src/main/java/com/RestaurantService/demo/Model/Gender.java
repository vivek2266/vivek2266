package com.RestaurantService.demo.Model;

public enum Gender {

    MALE, FEMALE
}
