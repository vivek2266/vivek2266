package com.RestaurantService.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestaurantServiceApplicationTests {


	@Test
	void contextLoads() {
	}

}
