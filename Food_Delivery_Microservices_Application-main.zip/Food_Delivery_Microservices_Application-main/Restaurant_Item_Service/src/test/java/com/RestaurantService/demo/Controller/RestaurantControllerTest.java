package com.RestaurantService.demo.Controller;

import com.RestaurantService.demo.Model.Restaurant;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
class RestaurantControllerTest {

    @Autowired
    RestaurantController restaurantController;

    @Test
    void addRestaurant() {

        Restaurant restaurant = new Restaurant();


    }

    @Test
    void updateRestaurant() {
    }

    @Test
    void removeRestaurant() {
    }

    @Test
    void viewRestaurant() {
    }

    @Test
    void getNearByRestaurant() {
    }

    @Test
    void viewRestaurantByItem() {
    }

    @Test
    void addItemToRestaurant() {
    }
}