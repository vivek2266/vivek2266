package com.CategoryService.demo.Model;

public enum Gender {

    MALE, FEMALE
}
