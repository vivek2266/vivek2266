package com.CategoryService.demo.Exceptions;

public class CategoryException extends RuntimeException{
    public CategoryException() {
    }

    public CategoryException(String message) {
        super(message);
    }
}
