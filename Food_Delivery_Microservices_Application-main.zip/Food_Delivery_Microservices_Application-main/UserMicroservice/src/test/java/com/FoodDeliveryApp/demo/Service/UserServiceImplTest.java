package com.FoodDeliveryApp.demo.Service;

import com.FoodDeliveryApp.demo.Repository.UserRepository;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;

import static org.junit.jupiter.api.Assertions.*;

class UserServiceImplTest {

    @Autowired
    UserService userService;

    @Autowired
    UserRepository userRepository;


    @Test
    void registerUser() {




    }

    @Test
    void updateUser() {
    }

    @Test
    void removeUser() {
    }

    @Test
    void viewUser() {
    }

    @Test
    void viewAllUser() {
    }
}