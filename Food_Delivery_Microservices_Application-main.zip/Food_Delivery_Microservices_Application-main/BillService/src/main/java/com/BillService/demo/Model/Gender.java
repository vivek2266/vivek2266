package com.BillService.demo.Model;

public enum Gender {

    MALE, FEMALE
}
