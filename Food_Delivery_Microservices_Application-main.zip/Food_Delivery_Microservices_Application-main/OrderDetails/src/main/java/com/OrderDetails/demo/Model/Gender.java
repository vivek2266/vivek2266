package com.OrderDetails.demo.Model;

public enum Gender {

    MALE, FEMALE
}
