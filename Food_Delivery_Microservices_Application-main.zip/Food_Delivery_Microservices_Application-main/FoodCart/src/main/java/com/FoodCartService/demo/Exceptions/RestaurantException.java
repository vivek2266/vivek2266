package com.FoodCartService.demo.Exceptions;

public class RestaurantException extends RuntimeException{
    public RestaurantException() {
    }

    public RestaurantException(String message) {
        super(message);
    }
}
