package com.FoodCartService.demo.Model;

public enum Gender {

    MALE, FEMALE
}
