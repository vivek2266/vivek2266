package com.assessment.order.dto;

/**
 * @author Krishna Chaitanya
 */
public record Items(int itemId, int quantity, String notes) {
}
