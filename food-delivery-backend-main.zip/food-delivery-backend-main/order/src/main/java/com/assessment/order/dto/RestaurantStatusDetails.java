package com.assessment.order.dto;

/**
 * @author Krishna Chaitanya
 */
public record RestaurantStatusDetails(int orderId, String status) {
}
