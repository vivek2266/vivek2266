package com.assessment.order.dto;

/**
 * @author Krishna Chaitanya
 */
public record OrderStatusResponse(int orderId, OrderStatus orderStatus) {
}
