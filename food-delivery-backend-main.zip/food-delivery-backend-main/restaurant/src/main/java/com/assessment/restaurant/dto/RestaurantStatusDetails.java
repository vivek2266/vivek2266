package com.assessment.restaurant.dto;

/**
 * @author Krishna Chaitanya
 */
public record RestaurantStatusDetails(int orderId, String status) {
}
